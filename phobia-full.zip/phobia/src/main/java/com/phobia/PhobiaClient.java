package com.phobia;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

// Gives the mod an in-game settings screen under Mods -> Phobia -> Config.
@Mod(value = Phobia.MODID, dist = Dist.CLIENT)
public class PhobiaClient {
    public PhobiaClient(ModContainer container) {
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
    }
}
