package com.phobia;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

// HUD: sanity bar above the health bar, stamina bar above the hunger bar (shown only when not full),
// and a red tint at low sanity.
@EventBusSubscriber(modid = Phobia.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void registerLayers(RegisterGuiLayersEvent e) {
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "bars"),
                (gg, delta) -> render(gg));
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "blink"),
                (gg, delta) -> ClientBlink.render(gg));
    }

    private static void render(GuiGraphics gg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        int w = gg.guiWidth();
        int h = gg.guiHeight();

        // Low-sanity tint
        if (ClientStats.sanity < 30f) {
            float panic = 1f - ClientStats.sanity / 30f;
            int a = (int) (panic * 90f);
            gg.fill(0, 0, w, h, (a << 24) | 0x300000);
        }

        // Vanilla health/hunger rows are 81px wide on each side of the hotbar.
        // Armor and air bubbles start 49px above the bottom, so we sit just above them.
        int cx = w / 2;
        int bw = 81;
        int bh = 5;
        int by = h - 58;

        // Left side (above health): sanity
        int lx = cx - 91;
        gg.drawString(mc.font, Component.translatable("hud.phobia.sanity"), lx, by - 10, 0xFFCCCCCC);
        bar(gg, lx, by, bw, bh, ClientStats.sanity / 100f, 0xFF8A6BFF);

        // Right side (above hunger): stamina
        if (ClientStats.exhausted || ClientStats.stamina < ClientStats.staminaMax - 0.5f) {
            int rx = cx + 10;
            int color = ClientStats.exhausted ? 0xFFCC3333 : 0xFF3FBF5F;
            gg.drawString(mc.font, Component.translatable("hud.phobia.stamina"), rx, by - 10, 0xFFCCCCCC);
            bar(gg, rx, by, bw, bh, ClientStats.stamina / Math.max(1f, ClientStats.staminaMax), color);
        }
    }

    private static void bar(GuiGraphics gg, int x, int y, int w, int h, float frac, int color) {
        frac = Math.max(0f, Math.min(1f, frac));
        gg.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xAA000000);
        gg.fill(x, y, x + (int) (w * frac), y + h, color);
    }
}
