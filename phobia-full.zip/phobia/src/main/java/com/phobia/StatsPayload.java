package com.phobia;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

// Server -> client: current stats so the HUD and client effects can use them.
public record StatsPayload(float sanity, float stamina, float staminaMax, boolean exhausted,
                           int insomnia, float blinkSeconds) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<StatsPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "stats"));

    public static final StreamCodec<ByteBuf, StatsPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.FLOAT, StatsPayload::sanity,
            ByteBufCodecs.FLOAT, StatsPayload::stamina,
            ByteBufCodecs.FLOAT, StatsPayload::staminaMax,
            ByteBufCodecs.BOOL, StatsPayload::exhausted,
            ByteBufCodecs.VAR_INT, StatsPayload::insomnia,
            ByteBufCodecs.FLOAT, StatsPayload::blinkSeconds,
            StatsPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(StatsPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientStats.update(payload));
    }
}
