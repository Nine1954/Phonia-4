package com.phobia;

// Client-side copy of the local player's stats. Plain data, safe to load on any side.
public final class ClientStats {
    public static float sanity = 100f;
    public static float stamina = 100f;
    public static float staminaMax = 100f;
    public static boolean exhausted = false;
    public static int insomnia = 0;
    public static float blinkSeconds = 9f;

    public static void update(StatsPayload p) {
        sanity = p.sanity();
        stamina = p.stamina();
        staminaMax = p.staminaMax();
        exhausted = p.exhausted();
        insomnia = p.insomnia();
        blinkSeconds = p.blinkSeconds();
    }

    public static void reset() {
        sanity = 100f;
        stamina = 100f;
        staminaMax = 100f;
        exhausted = false;
        insomnia = 0;
        blinkSeconds = 9f;
    }
}
