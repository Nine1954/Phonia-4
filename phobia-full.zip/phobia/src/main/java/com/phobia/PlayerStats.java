package com.phobia;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.server.level.ServerPlayer;

public class PlayerStats {
    public static final Codec<PlayerStats> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.FLOAT.optionalFieldOf("sanity", 100f).forGetter(s -> s.sanity),
            Codec.FLOAT.optionalFieldOf("stamina", 100f).forGetter(s -> s.stamina),
            Codec.BOOL.optionalFieldOf("exhausted", false).forGetter(s -> s.exhausted),
            Codec.LONG.optionalFieldOf("lastSleepDay", -1L).forGetter(s -> s.lastSleepDay)
    ).apply(i, (sanity, stamina, exhausted, lastSleepDay) ->
            new PlayerStats(sanity, stamina, exhausted, lastSleepDay)));

    // Saved
    public float sanity = 100f;
    public float stamina = 100f;
    public boolean exhausted = false;
    public long lastSleepDay = -1L;

    // Runtime only (not saved)
    public float lastExhaustion = 0f;
    public boolean lastSprinting = false;
    public int secondTimer = 0;
    public int cheatTicks = -1;
    public float fatigue = 0f;
    public int recoveryDelay = 0;
    public long blinkClosedUntil = 0L;
    public boolean wasSleepingLong = false;
    public int spawnCooldown = 60;
    public int insomnia = 0;

    public float sentSanity = -1f;
    public float sentStamina = -1f;
    public float sentMax = -1f;
    public float sentBlink = -1f;
    public int sentInsomnia = -1;
    public boolean sentExhausted = false;

    public PlayerStats() {}

    public PlayerStats(float sanity, float stamina, boolean exhausted, long lastSleepDay) {
        this.sanity = sanity;
        this.stamina = stamina;
        this.exhausted = exhausted;
        this.lastSleepDay = lastSleepDay;
    }

    // True while the player's eyes are closed (blinking, holding the blink key, or asleep).
    public boolean isBlinking(ServerPlayer p) {
        return p.isSleeping() || p.level().getGameTime() < blinkClosedUntil;
    }

    public static void addSanity(ServerPlayer sp, float delta) {
        PlayerStats s = sp.getData(Phobia.STATS);
        s.sanity = Math.max(0f, Math.min(100f, s.sanity + delta));
    }
}
