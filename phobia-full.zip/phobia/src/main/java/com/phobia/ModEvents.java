package com.phobia;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

@EventBusSubscriber(modid = Phobia.MODID, bus = EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.FACELESS_DOLL.get(),
                GhostEntity.createAttributes().add(Attributes.MOVEMENT_SPEED, 0.27).build());
        e.put(ModEntities.CROW_WATCHER.get(),
                GhostEntity.createAttributes().add(Attributes.MOVEMENT_SPEED, 0.2).build());
        e.put(ModEntities.SHADE.get(),
                GhostEntity.createAttributes().add(Attributes.MOVEMENT_SPEED, 0.24).build());
    }
}
