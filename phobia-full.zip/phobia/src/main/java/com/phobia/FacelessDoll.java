package com.phobia;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

// The hunter. It only moves while nobody is looking at it (eyes open, in view, clear line of sight).
// The moment you blink or turn away it closes the distance.
public class FacelessDoll extends GhostEntity {
    private int repath = 0;

    public FacelessDoll(EntityType<? extends GhostEntity> type, Level level) {
        super(type, level);
        this.lifeTicks = 20 * 150;
    }

    @Override
    protected void ghostPreTick() {
        if (tickCount % 2 == 0) {
            frozen = Observation.isObservedByAny((ServerLevel) level(), this, 64.0);
        }
        if (frozen) getNavigation().stop();
    }

    @Override
    protected void customServerAiStep() {
        Player p = hunted();
        if (p == null) return;
        if (--repath <= 0) {
            repath = 8;
            getNavigation().moveTo(p, difficulty().speed);
        }
        if (distanceToSqr(p) < 2.25 && hasLineOfSight(p)) {
            touch(p);
        }
    }

    private void touch(Player p) {
        if (!(p instanceof ServerPlayer sp)) return;
        PhobiaConfig.GhostDifficulty d = difficulty();
        sp.hurt(damageSources().mobAttack(this), 6.0f * d.damage);
        PlayerStats.addSanity(sp, -35f * d.damage);
        sp.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0));
        playSound(SoundEvents.ENDERMAN_SCREAM, 1.0f, 0.6f);
        vanish();
    }

    @Override
    protected SoundEvent vanishSound() {
        return SoundEvents.ENDERMAN_TELEPORT;
    }
}
