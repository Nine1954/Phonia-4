package com.phobia;

import java.util.Locale;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

// /phobia stamina loss|gain|max|resume|delay <value>
// /phobia sanity <0-100>
// /phobia difficulty full|aggressive|insane
// /phobia spawn doll|crow|shade        (test spawn near you)
// /phobia insomnia <nights>            (pretend you have not slept for N nights)
@EventBusSubscriber(modid = Phobia.MODID)
public class PhobiaCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        LiteralArgumentBuilder<CommandSourceStack> difficulty = Commands.literal("difficulty");
        for (PhobiaConfig.GhostDifficulty d : PhobiaConfig.GhostDifficulty.values()) {
            difficulty.then(Commands.literal(d.name().toLowerCase(Locale.ROOT))
                    .executes(c -> setDifficulty(c, d)));
        }

        LiteralArgumentBuilder<CommandSourceStack> spawn = Commands.literal("spawn");
        spawn.then(Commands.literal("doll").executes(c -> spawnGhost(c, ModEntities.FACELESS_DOLL.get())));
        spawn.then(Commands.literal("crow").executes(c -> spawnGhost(c, ModEntities.CROW_WATCHER.get())));
        spawn.then(Commands.literal("shade").executes(c -> spawnGhost(c, ModEntities.SHADE.get())));

        e.getDispatcher().register(Commands.literal("phobia")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("stamina")
                        .then(value("loss", PhobiaConfig.STAMINA_LOSS))
                        .then(value("gain", PhobiaConfig.STAMINA_GAIN))
                        .then(value("max", PhobiaConfig.STAMINA_MAX))
                        .then(value("resume", PhobiaConfig.STAMINA_RESUME))
                        .then(value("delay", PhobiaConfig.STAMINA_RECOVERY_DELAY)))
                .then(Commands.literal("sanity")
                        .then(Commands.argument("value", FloatArgumentType.floatArg(0f, 100f))
                                .executes(PhobiaCommands::setSanity)))
                .then(difficulty)
                .then(spawn)
                .then(Commands.literal("insomnia")
                        .then(Commands.argument("nights", IntegerArgumentType.integer(0, 10))
                                .executes(PhobiaCommands::setInsomnia))));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> value(String name, ModConfigSpec.DoubleValue cfg) {
        return Commands.literal(name)
                .executes(c -> {
                    c.getSource().sendSuccess(() -> Component.literal(name + " = " + cfg.get()), false);
                    return 1;
                })
                .then(Commands.argument("value", DoubleArgumentType.doubleArg(0.0, 1000.0))
                        .executes(c -> {
                            double v = DoubleArgumentType.getDouble(c, "value");
                            cfg.set(v);
                            cfg.save();
                            c.getSource().sendSuccess(() -> Component.literal(name + " set to " + v), true);
                            return 1;
                        }));
    }

    private static int setSanity(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer sp = c.getSource().getPlayerOrException();
        PlayerStats s = sp.getData(Phobia.STATS);
        s.sanity = FloatArgumentType.getFloat(c, "value");
        ServerEvents.send(sp, s);
        c.getSource().sendSuccess(() -> Component.literal("sanity = " + s.sanity), false);
        return 1;
    }

    private static int setDifficulty(CommandContext<CommandSourceStack> c, PhobiaConfig.GhostDifficulty d) {
        PhobiaConfig.DIFFICULTY.set(d);
        PhobiaConfig.DIFFICULTY.save();
        c.getSource().sendSuccess(() -> Component.literal("difficulty = " + d.name()), true);
        return 1;
    }

    private static int spawnGhost(CommandContext<CommandSourceStack> c, EntityType<? extends GhostEntity> type)
            throws CommandSyntaxException {
        ServerPlayer sp = c.getSource().getPlayerOrException();
        boolean ok = GhostSpawner.spawnNear(sp, type, true);
        c.getSource().sendSuccess(() -> Component.literal(ok ? "spawned" : "no valid spot nearby, try again"), false);
        return ok ? 1 : 0;
    }

    private static int setInsomnia(CommandContext<CommandSourceStack> c) throws CommandSyntaxException {
        ServerPlayer sp = c.getSource().getPlayerOrException();
        PlayerStats s = sp.getData(Phobia.STATS);
        int nights = IntegerArgumentType.getInteger(c, "nights");
        s.lastSleepDay = ServerEvents.dayOf(sp) - nights;
        c.getSource().sendSuccess(() -> Component.literal("pretending you have not slept for " + nights + " night(s)"), false);
        return 1;
    }
}
