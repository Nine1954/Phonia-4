package com.phobia;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

// Decides when and where ghosts appear. Rare on purpose: one attempt every few minutes per player.
public class GhostSpawner {

    // Called once per second for each survival player.
    public static void tick(ServerPlayer sp, PlayerStats s) {
        if (!PhobiaConfig.GHOSTS_ENABLED.get()) return;
        ServerLevel level = sp.serverLevel();
        if (level.dimension() != Level.OVERWORLD || sp.isSleeping()) return;

        if (s.spawnCooldown > 0) {
            s.spawnCooldown--;
            return;
        }

        PhobiaConfig.GhostDifficulty d = PhobiaConfig.DIFFICULTY.get();
        int near = level.getEntitiesOfClass(GhostEntity.class, sp.getBoundingBox().inflate(48.0)).size();
        if (near >= d.cap) {
            s.spawnCooldown = 20;
            return;
        }

        BlockPos pos = sp.blockPosition();
        long t = level.getDayTime() % 24000L;
        boolean night = t >= 13000L && t <= 23000L;
        boolean storm = level.isThundering();
        boolean sky = level.canSeeSky(pos);
        boolean cave = !sky && pos.getY() < level.getSeaLevel() - 4;

        float chance;
        int kind; // 0 = anything, 1 = daytime peeker only, 2 = cave mix
        if (cave) {
            chance = 0.35f;
            kind = 2;
        } else if (night || storm) {
            chance = 0.5f + (storm ? 0.25f : 0f);
            kind = 0;
        } else {
            chance = 0.12f;
            kind = 1;
        }
        chance *= d.spawn * (1.0f + (1.0f - s.sanity / 100f));
        chance = Math.min(chance, 0.95f);

        int min = PhobiaConfig.GHOST_INTERVAL_MIN.get();
        int max = Math.max(min, PhobiaConfig.GHOST_INTERVAL_MAX.get());
        int interval = (int) ((min + level.random.nextInt(max - min + 1)) / d.spawn);

        if (level.random.nextFloat() >= chance) {
            s.spawnCooldown = Math.max(20, interval / 3); // failed roll: try again sooner
            return;
        }

        EntityType<? extends GhostEntity> type = pick(kind, level.random.nextFloat());

        if (spawnNear(sp, type, false)) {
            s.spawnCooldown = interval;
        } else {
            s.spawnCooldown = 30;
        }
    }

    private static EntityType<? extends GhostEntity> pick(int kind, float r) {
        if (kind == 1) return ModEntities.CROW_WATCHER.get();
        if (kind == 2) {
            if (r < 0.6f) return ModEntities.SHADE.get();
            if (r < 0.8f) return ModEntities.CROW_WATCHER.get();
            return ModEntities.FACELESS_DOLL.get();
        }
        if (r < 0.35f) return ModEntities.FACELESS_DOLL.get();
        if (r < 0.7f) return ModEntities.CROW_WATCHER.get();
        return ModEntities.SHADE.get();
    }

    // test = true: ignore view / tree rules and spawn 10-14 blocks away (used by /phobia spawn)
    public static boolean spawnNear(ServerPlayer sp, EntityType<? extends GhostEntity> type, boolean test) {
        ServerLevel level = sp.serverLevel();
        boolean crow = type == ModEntities.CROW_WATCHER.get();
        boolean shade = type == ModEntities.SHADE.get();
        long t = level.getDayTime() % 24000L;
        boolean daytime = !(t >= 13000L && t <= 23000L) && !level.isThundering();

        double minD = test ? 10 : (crow ? 18 : 16);
        double maxD = test ? 14 : (crow ? 30 : 26);

        Vec3 look = sp.getLookAngle();
        BlockPos base = sp.blockPosition();

        for (int attempt = 0; attempt < 24; attempt++) {
            double ang = level.random.nextDouble() * Math.PI * 2.0;
            double dist = minD + level.random.nextDouble() * (maxD - minD);
            int x = base.getX() + (int) Math.round(Math.cos(ang) * dist);
            int z = base.getZ() + (int) Math.round(Math.sin(ang) * dist);

            BlockPos p = findFloor(level, x, z, base.getY() + 6, base.getY() - 10);
            if (p == null) continue;

            if (!test) {
                Vec3 to = new Vec3(p.getX() + 0.5 - sp.getX(), 0, p.getZ() + 0.5 - sp.getZ()).normalize();
                if (look.multiply(1, 0, 1).normalize().dot(to) > 0.35) continue; // must be outside the player's view
                if (crow && daytime && !underTrees(level, p)) continue;
                if (shade && level.getMaxLocalRawBrightness(p) > PhobiaConfig.DARK_LIGHT_LEVEL.get() + 4) continue;
            }

            GhostEntity g = type.create(level);
            if (g == null) return false;
            g.moveTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, level.random.nextFloat() * 360f, 0f);
            g.setHunted(sp);
            level.addFreshEntity(g);
            return true;
        }
        return false;
    }

    private static boolean underTrees(ServerLevel level, BlockPos p) {
        for (int dy = 2; dy <= 10; dy++) {
            if (level.getBlockState(p.above(dy)).is(BlockTags.LEAVES)) return true;
        }
        return false;
    }

    private static BlockPos findFloor(ServerLevel level, int x, int z, int topY, int bottomY) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = topY; y >= bottomY; y--) {
            m.set(x, y, z);
            if (!level.hasChunkAt(m)) return null;
            BlockPos below = m.below();
            var floor = level.getBlockState(below);
            if (floor.getCollisionShape(level, below).isEmpty() || !floor.getFluidState().isEmpty()) continue;
            if (!level.getBlockState(m).getCollisionShape(level, m).isEmpty() || !level.getFluidState(m).isEmpty()) continue;
            BlockPos above = m.above();
            if (!level.getBlockState(above).getCollisionShape(level, above).isEmpty()) continue;
            return m.immutable();
        }
        return null;
    }
}
