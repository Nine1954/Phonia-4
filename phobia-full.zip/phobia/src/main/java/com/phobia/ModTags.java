package com.phobia;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;

public class ModTags {
    // Anything in this tag scares the player. Add your own crow entity here later.
    public static final TagKey<EntityType<?>> BIRDS =
            TagKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "birds"));
}
