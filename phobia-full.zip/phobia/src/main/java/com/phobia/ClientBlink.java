package com.phobia;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

// Eye system. Your eyes dry out over time and force a blink (screen goes black for a moment).
// You can also blink on purpose by holding the blink key (default B). Ghosts move while your eyes are closed.
// Low sanity and lack of sleep make the eyes dry out faster and the blinks longer.
@EventBusSubscriber(modid = Phobia.MODID, value = Dist.CLIENT)
public class ClientBlink {
    public static final KeyMapping BLINK_KEY =
            new KeyMapping("key.phobia.blink", InputConstants.KEY_B, "key.categories.phobia");

    public static int flicker = 0;

    private static float strain = 0f;
    private static int autoTicks = 0;
    private static boolean closed = false;
    private static int heartbeat = 0;

    public static void reset() {
        strain = 0f;
        autoTicks = 0;
        closed = false;
        heartbeat = 0;
        flicker = 0;
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer pl = mc.player;
        if (pl == null || mc.isPaused()) return;

        if (flicker > 0) flicker--;

        boolean held = BLINK_KEY.isDown() && mc.screen == null;
        float panic = 1f - ClientStats.sanity / 100f;
        int insomnia = ClientStats.insomnia;

        float rate = 100f / (Math.max(2f, ClientStats.blinkSeconds) * 20f)
                * (1f + panic * 1.2f + insomnia * 0.6f);

        if (held) {
            strain = Math.max(0f, strain - 6f);
        } else if (autoTicks == 0) {
            strain += rate;
        }
        if (strain >= 100f && autoTicks == 0) {
            autoTicks = 4 + insomnia * 2;
            strain = 0f;
        }
        if (autoTicks > 0) autoTicks--;

        boolean nowClosed = held || autoTicks > 0;
        if (nowClosed != closed) {
            closed = nowClosed;
            PacketDistributor.sendToServer(new BlinkPayload(closed));
            heartbeat = 0;
        } else if (closed && ++heartbeat >= 8) {
            PacketDistributor.sendToServer(new BlinkPayload(true));
            heartbeat = 0;
        }
    }

    public static void render(GuiGraphics gg) {
        int w = gg.guiWidth();
        int h = gg.guiHeight();

        if (closed) {
            gg.fill(0, 0, w, h, 0xFF000000);
            return;
        }
        if (flicker > 0) {
            gg.fill(0, 0, w, h, 0x99000000);
        }

        // Dry eyes darken the edges of the screen; lack of sleep adds bloodshot red.
        float edge = Math.max(0f, (strain - 55f) / 45f);
        float red = Math.min(1f, ClientStats.insomnia / 4f);
        if (edge <= 0f && red <= 0f) return;

        int bands = 6;
        float maxThick = Math.min(w, h) * (0.22f * edge + 0.12f * red);
        int rgb = red > 0.1f ? 0x300000 : 0x000000;
        int alpha = (int) (28 + 30 * Math.max(edge, red));
        for (int i = 0; i < bands; i++) {
            int t = (int) (maxThick * (1f - i / (float) bands));
            if (t <= 0) continue;
            int col = (alpha << 24) | rgb;
            gg.fill(0, 0, w, t, col);
            gg.fill(0, h - t, w, h, col);
            gg.fill(0, 0, t, h, col);
            gg.fill(w - t, 0, w, h, col);
        }
    }
}
