package com.phobia;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

// One renderer for all humanoid ghosts: a texture and a body scale are the only differences.
public class GhostRenderer extends HumanoidMobRenderer<GhostEntity, HumanoidModel<GhostEntity>> {
    private final ResourceLocation texture;
    private final float scaleXZ;
    private final float scaleY;

    public GhostRenderer(EntityRendererProvider.Context ctx, HumanoidModel<GhostEntity> model,
                         String textureName, float scaleXZ, float scaleY) {
        super(ctx, model, 0.0f);
        this.texture = ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "textures/entity/" + textureName + ".png");
        this.scaleXZ = scaleXZ;
        this.scaleY = scaleY;
    }

    @Override
    public ResourceLocation getTextureLocation(GhostEntity entity) {
        return texture;
    }

    @Override
    protected void scale(GhostEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(scaleXZ, scaleY, scaleXZ);
    }
}
