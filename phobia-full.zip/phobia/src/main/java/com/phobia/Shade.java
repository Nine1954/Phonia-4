package com.phobia;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

// A thing of the dark. Chases you at a steady pace but cannot stand light:
// in bright places it flees and dissolves after a few seconds. Daylight destroys it.
public class Shade extends GhostEntity {
    private int litTicks = 0;
    private boolean lit = false;
    private int repath = 0;

    public Shade(EntityType<? extends GhostEntity> type, Level level) {
        super(type, level);
        this.lifeTicks = 20 * 100;
    }

    @Override
    protected void ghostPreTick() {
        if (tickCount % 5 != 0) return;
        lit = level().getMaxLocalRawBrightness(blockPosition()) >= 9;
        if (lit) {
            litTicks += 5;
            if (litTicks >= 60) {
                vanish();
            }
        } else {
            litTicks = Math.max(0, litTicks - 5);
        }
    }

    @Override
    protected void customServerAiStep() {
        Player p = hunted();
        if (p == null) return;
        PhobiaConfig.GhostDifficulty d = difficulty();

        if (--repath <= 0) {
            repath = 8;
            if (lit) {
                Vec3 away = position().subtract(p.position()).multiply(1, 0, 1).normalize().scale(10.0);
                getNavigation().moveTo(getX() + away.x, getY(), getZ() + away.z, 1.3 * d.speed);
            } else {
                getNavigation().moveTo(p, d.speed);
            }
        }

        if (!lit && distanceToSqr(p) < 2.25 && hasLineOfSight(p) && p instanceof ServerPlayer sp) {
            sp.hurt(damageSources().mobAttack(this), 3.0f * d.damage);
            PlayerStats.addSanity(sp, -20f * d.damage);
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            playSound(SoundEvents.WARDEN_NEARBY_CLOSER, 1.0f, 0.7f);
            vanish();
        }
    }

    @Override
    protected SoundEvent vanishSound() {
        return SoundEvents.WARDEN_SNIFF;
    }
}
