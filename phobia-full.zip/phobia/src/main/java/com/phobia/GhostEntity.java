package com.phobia;

import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

// Base class for all ghosts. Ghosts cannot be hurt, have a limited lifetime and are driven
// by small server-side behaviours instead of vanilla goals.
public abstract class GhostEntity extends PathfinderMob {
    protected boolean frozen = false;
    protected int lifeTicks = 20 * 120;
    private UUID huntedId;

    protected GhostEntity(EntityType<? extends GhostEntity> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    public void setHunted(Player p) {
        this.huntedId = p.getUUID();
    }

    protected Player hunted() {
        Player p = huntedId != null ? level().getPlayerByUUID(huntedId) : null;
        if (p == null || !p.isAlive() || p.isSpectator() || p.isCreative()) {
            p = level().getNearestPlayer(this, 64.0);
            if (p != null) huntedId = p.getUUID();
        }
        return p;
    }

    protected PhobiaConfig.GhostDifficulty difficulty() {
        return PhobiaConfig.DIFFICULTY.get();
    }

    @Override
    public void tick() {
        if (!level().isClientSide) {
            if (tickCount > lifeTicks) {
                vanish();
                return;
            }
            ghostPreTick();
        }
        super.tick();
    }

    // Runs on the server before the normal tick. Set `frozen` here.
    protected void ghostPreTick() {}

    @Override
    protected boolean isImmobile() {
        return frozen || super.isImmobile();
    }

    @Override
    public boolean fireImmune() {
        return true;
    }

    protected SoundEvent vanishSound() {
        return SoundEvents.BAT_TAKEOFF;
    }

    public void vanish() {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + getBbHeight() * 0.5, getZ(),
                    25, 0.3, 0.7, 0.3, 0.02);
            sl.playSound(null, blockPosition(), vanishSound(),
                    net.minecraft.sounds.SoundSource.HOSTILE, 0.8f, 0.7f);
        }
        discard();
    }
}
