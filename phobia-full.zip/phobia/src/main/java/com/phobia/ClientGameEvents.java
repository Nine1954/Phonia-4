package com.phobia;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

// Client-only effects driven by sanity and sleep:
// - heartbeat gets faster and louder as sanity drops below 40
// - hallucinations (sounds from behind you, brief dark flickers) at low sanity or after nights without sleep
@EventBusSubscriber(modid = Phobia.MODID, value = Dist.CLIENT)
public class ClientGameEvents {
    private static int beat = 0;
    private static int halluTimer = 0;

    private static final SoundEvent[] HALLU_SOUNDS = {
            SoundEvents.WOODEN_DOOR_OPEN,
            SoundEvents.ENDERMAN_STARE,
            SoundEvents.GLASS_BREAK,
            SoundEvents.ZOMBIE_AMBIENT,
            SoundEvents.WARDEN_NEARBY_CLOSE,
            SoundEvents.SKELETON_AMBIENT
    };

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.isPaused()) return;

        // Heartbeat
        if (ClientStats.sanity >= 40f) {
            beat = 0;
        } else {
            float panic = 1f - ClientStats.sanity / 40f; // 0..1
            int interval = (int) (40 - 22 * panic);
            if (++beat >= interval) {
                beat = 0;
                mc.getSoundManager().play(SimpleSoundInstance.forUI(
                        SoundEvents.WARDEN_HEARTBEAT, 0.5f + 0.4f * panic, 0.4f + 0.6f * panic));
            }
        }

        // Hallucinations: roll once per second
        if (++halluTimer >= 20) {
            halluTimer = 0;
            maybeHallucinate(mc);
        }
    }

    private static void maybeHallucinate(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;

        float p = 0f;
        if (ClientStats.sanity < 30f) p += (1f - ClientStats.sanity / 30f) * 0.12f;
        p += ClientStats.insomnia * 0.04f;
        if (p <= 0f || mc.level.random.nextFloat() >= p) return;

        // A sound from behind the player
        Vec3 look = mc.player.getLookAngle();
        double x = mc.player.getX() - look.x * 5.0;
        double z = mc.player.getZ() - look.z * 5.0;
        SoundEvent snd = HALLU_SOUNDS[mc.level.random.nextInt(HALLU_SOUNDS.length)];
        mc.level.playLocalSound(x, mc.player.getY(), z, snd, SoundSource.AMBIENT, 1.0f,
                0.7f + mc.level.random.nextFloat() * 0.3f, false);

        if (mc.level.random.nextFloat() < 0.3f) {
            ClientBlink.flicker = 3 + mc.level.random.nextInt(3);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientStats.reset();
        ClientBlink.reset();
        beat = 0;
        halluTimer = 0;
    }
}
