package com.phobia;

import java.util.List;

import net.neoforged.neoforge.common.ModConfigSpec;

public class PhobiaConfig {
    public enum CheatMode { OFF, KILL, KICK }

    // speed: ghost speed, spawn: spawn chance, damage: touch damage/sanity damage,
    // sanity: environmental sanity loss, cap: max ghosts near one player
    public enum GhostDifficulty {
        FULL(1.0f, 1.0f, 1.0f, 1.0f, 1),
        AGGRESSIVE(1.25f, 1.7f, 1.5f, 1.3f, 2),
        INSANE(1.5f, 2.6f, 2.5f, 1.7f, 3);

        public final float speed;
        public final float spawn;
        public final float damage;
        public final float sanity;
        public final int cap;

        GhostDifficulty(float speed, float spawn, float damage, float sanity, int cap) {
            this.speed = speed;
            this.spawn = spawn;
            this.damage = damage;
            this.sanity = sanity;
            this.cap = cap;
        }
    }

    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    // ---- Difficulty / ghosts ----
    public static final ModConfigSpec.EnumValue<GhostDifficulty> DIFFICULTY = B
            .comment("FULL = baseline, AGGRESSIVE = faster/more/harder ghosts, INSANE = brutal")
            .defineEnum("difficulty", GhostDifficulty.FULL);
    public static final ModConfigSpec.BooleanValue GHOSTS_ENABLED = B
            .comment("Turn natural ghost spawning on or off")
            .define("ghostsEnabled", true);
    public static final ModConfigSpec.IntValue GHOST_INTERVAL_MIN = B
            .comment("Minimum seconds between ghost spawn attempts per player")
            .defineInRange("ghostIntervalMinSec", 120, 10, 3600);
    public static final ModConfigSpec.IntValue GHOST_INTERVAL_MAX = B
            .comment("Maximum seconds between ghost spawn attempts per player")
            .defineInRange("ghostIntervalMaxSec", 300, 10, 7200);

    // ---- Eyes / blinking ----
    public static final ModConfigSpec.DoubleValue BLINK_SECONDS = B
            .comment("Seconds until your eyes force a blink (at full sanity, well rested)")
            .defineInRange("autoBlinkSeconds", 9.0, 2.0, 60.0);
    public static final ModConfigSpec.IntValue INSOMNIA_NIGHTS = B
            .comment("Nights without sleep before eye inflammation starts")
            .defineInRange("insomniaNights", 2, 1, 20);

    // ---- Stamina ----
    public static final ModConfigSpec.DoubleValue STAMINA_MAX = B
            .comment("Maximum stamina")
            .defineInRange("staminaMax", 100.0, 10.0, 1000.0);
    public static final ModConfigSpec.DoubleValue STAMINA_LOSS = B
            .comment("Stamina lost per second while sprinting")
            .defineInRange("staminaLossPerSec", 10.0, 0.0, 1000.0);
    public static final ModConfigSpec.DoubleValue STAMINA_GAIN = B
            .comment("Stamina regained per second when not sprinting")
            .defineInRange("staminaGainPerSec", 20.0, 0.0, 1000.0);
    public static final ModConfigSpec.DoubleValue STAMINA_RESUME = B
            .comment("After running out, stamina must reach this value before you can sprint properly again")
            .defineInRange("staminaResumeAt", 20.0, 0.0, 1000.0);
    public static final ModConfigSpec.DoubleValue STAMINA_RECOVERY_DELAY = B
            .comment("Seconds to wait after running out of stamina before it starts to recover")
            .defineInRange("staminaRecoveryDelaySec", 2.0, 0.0, 60.0);
    public static final ModConfigSpec.DoubleValue STAMINA_FATIGUE_FACTOR = B
            .comment("Progressive recovery: the longer you sprint without rest, the slower stamina recovers. 0 = off")
            .defineInRange("staminaFatigueFactor", 0.05, 0.0, 5.0);
    public static final ModConfigSpec.DoubleValue SANITY_STAMINA_PENALTY = B
            .comment("At 0 sanity, stamina drains (1 + this) times faster and regenerates that much slower")
            .defineInRange("sanityStaminaPenalty", 1.0, 0.0, 10.0);

    // ---- Sanity ----
    public static final ModConfigSpec.IntValue DARK_LIGHT_LEVEL = B
            .comment("Light level at or below this counts as darkness")
            .defineInRange("darkLightLevel", 4, 0, 15);
    public static final ModConfigSpec.DoubleValue DARK_LOSS = B
            .comment("Sanity lost per second in darkness")
            .defineInRange("sanityLossDark", 0.5, 0.0, 100.0);
    public static final ModConfigSpec.IntValue TIGHT_MAX_FREE = B
            .comment("Out of the 50 cells around you (5x5, feet and head level), at most this many free cells = tight space")
            .defineInRange("tightSpaceMaxFreeCells", 16, 0, 50);
    public static final ModConfigSpec.DoubleValue TIGHT_LOSS = B
            .comment("Sanity lost per second in a tight space")
            .defineInRange("sanityLossTight", 0.5, 0.0, 100.0);
    public static final ModConfigSpec.IntValue BIRD_RANGE = B
            .comment("Distance in blocks at which birds scare you")
            .defineInRange("birdRange", 10, 1, 64);
    public static final ModConfigSpec.DoubleValue BIRD_LOSS = B
            .comment("Sanity lost per second per nearby bird (max 5 birds counted)")
            .defineInRange("sanityLossPerBird", 1.0, 0.0, 100.0);
    public static final ModConfigSpec.DoubleValue RECOVER = B
            .comment("Sanity regained per second when nothing is scaring you")
            .defineInRange("sanityRecoverPerSec", 0.2, 0.0, 100.0);

    // ---- Anti-cheat ----
    public static final ModConfigSpec.EnumValue<CheatMode> ANTICHEAT_MODE = B
            .comment("What happens when a player uses a cheat command: OFF, KILL or KICK")
            .defineEnum("antiCheatMode", CheatMode.KILL);
    public static final ModConfigSpec.BooleanValue ANTICHEAT_DEDICATED = B
            .comment("Also punish ops on dedicated servers (default false so admins are left alone)")
            .define("antiCheatOnDedicatedServer", false);
    public static final ModConfigSpec.ConfigValue<List<? extends String>> CHEAT_COMMANDS = B
            .comment("Commands that count as cheating (without the slash)")
            .defineListAllowEmpty("cheatCommands",
                    List.of("gamemode", "defaultgamemode", "give", "tp", "teleport", "kill", "effect",
                            "setblock", "fill", "summon", "clear", "xp", "experience", "enchant",
                            "attribute", "item", "loot", "time", "weather", "difficulty",
                            "gamerule", "spawnpoint", "setworldspawn"),
                    () -> "",
                    o -> o instanceof String);

    public static final ModConfigSpec SPEC = B.build();
}
