package com.phobia;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.resources.ResourceLocation;

// A humanoid body with a crow's beak stuck on the head.
public class CrowModel {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "crow_watcher"), "main");

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.getChild("head");

        // Upper and lower beak (texture area is the unused bottom half of the 64x64 texture)
        head.addOrReplaceChild("beak_top",
                CubeListBuilder.create().texOffs(0, 40).addBox(-1.0F, -4.0F, -8.0F, 2.0F, 2.0F, 4.0F),
                PartPose.ZERO);
        head.addOrReplaceChild("beak_bottom",
                CubeListBuilder.create().texOffs(0, 48).addBox(-1.0F, -2.0F, -7.0F, 2.0F, 1.0F, 3.0F),
                PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }
}
