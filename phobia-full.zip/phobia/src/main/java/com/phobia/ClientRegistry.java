package com.phobia;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

@EventBusSubscriber(modid = Phobia.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientRegistry {

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(CrowModel.LAYER, CrowModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        // Small, pale doll
        e.<GhostEntity>registerEntityRenderer(ModEntities.FACELESS_DOLL.get(),
                ctx -> new GhostRenderer(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)),
                        "faceless_doll", 0.85f, 0.85f));
        // Tall, thin, crow-headed figure
        e.<GhostEntity>registerEntityRenderer(ModEntities.CROW_WATCHER.get(),
                ctx -> new GhostRenderer(ctx, new HumanoidModel<>(ctx.bakeLayer(CrowModel.LAYER)),
                        "crow_watcher", 0.95f, 1.3f));
        // Black silhouette
        e.<GhostEntity>registerEntityRenderer(ModEntities.SHADE.get(),
                ctx -> new GhostRenderer(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)),
                        "shade", 1.0f, 1.08f));
    }

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(ClientBlink.BLINK_KEY);
    }
}
