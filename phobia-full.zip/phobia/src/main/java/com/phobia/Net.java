package com.phobia;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class Net {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(StatsPayload.TYPE, StatsPayload.CODEC, StatsPayload::handle);
        registrar.playToServer(BlinkPayload.TYPE, BlinkPayload.CODEC, BlinkPayload::handle);
    }
}
