package com.phobia;

import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

// The watcher. Never moves, never attacks. It stands far away facing you and slowly eats your sanity
// while you are not looking. Look straight at it for ~2 seconds, or walk up close, and it is gone.
public class CrowWatcher extends GhostEntity {
    private int stare = 0;

    public CrowWatcher(EntityType<? extends GhostEntity> type, Level level) {
        super(type, level);
        this.lifeTicks = 20 * 75;
    }

    @Override
    protected void ghostPreTick() {
        frozen = true;
        getNavigation().stop();

        Player p = hunted();
        if (p == null) return;

        lookAt(EntityAnchorArgument.Anchor.EYES, p.getEyePosition());
        setYBodyRot(getYRot());
        setYHeadRot(getYRot());

        if (tickCount % 2 != 0 || !(p instanceof ServerPlayer sp)) return;

        if (distanceTo(p) < 5.0f) {
            vanish();
            return;
        }

        if (Observation.isLookedAt(sp, this)) {
            stare += 2;
            if (stare >= 40) {
                vanish();
            }
        } else {
            stare = Math.max(0, stare - 1);
            // Being watched without looking back: drain once per second while it has a clear view
            if (tickCount % 20 == 0 && distanceTo(p) < 40.0f && hasLineOfSight(p)) {
                PlayerStats.addSanity(sp, -0.8f * difficulty().damage);
            }
        }
    }
}
