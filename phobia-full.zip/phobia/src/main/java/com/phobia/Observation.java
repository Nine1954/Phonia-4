package com.phobia;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

// "Is this player looking at that entity right now?" Used by every blink / peek ghost.
public class Observation {
    // cos(56 degrees): a little wider than the real view so ghosts never move while barely in sight
    private static final double COS_HALF_FOV = 0.56;

    public static boolean isLookedAt(ServerPlayer p, Entity e) {
        if (p.isSpectator()) return false;
        PlayerStats st = p.getData(Phobia.STATS);
        if (st.isBlinking(p)) return false;

        Vec3 eye = p.getEyePosition();
        Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
        double dist = to.length();
        if (dist < 0.001) return true;
        double dot = p.getViewVector(1.0F).dot(to.scale(1.0 / dist));
        if (dot < COS_HALF_FOV) return false;
        return p.hasLineOfSight(e);
    }

    public static boolean isObservedByAny(ServerLevel level, Entity e, double range) {
        double r2 = range * range;
        for (ServerPlayer p : level.players()) {
            if (p.isSpectator() || p.distanceToSqr(e) > r2) continue;
            if (isLookedAt(p, e)) return true;
        }
        return false;
    }
}
