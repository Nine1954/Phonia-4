package com.phobia;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, Phobia.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<FacelessDoll>> FACELESS_DOLL =
            ENTITIES.register("faceless_doll", () -> EntityType.Builder
                    .of(FacelessDoll::new, MobCategory.MISC)
                    .sized(0.6f, 1.45f)
                    .clientTrackingRange(10)
                    .build("faceless_doll"));

    public static final DeferredHolder<EntityType<?>, EntityType<CrowWatcher>> CROW_WATCHER =
            ENTITIES.register("crow_watcher", () -> EntityType.Builder
                    .of(CrowWatcher::new, MobCategory.MISC)
                    .sized(0.6f, 2.4f)
                    .clientTrackingRange(16)
                    .build("crow_watcher"));

    public static final DeferredHolder<EntityType<?>, EntityType<Shade>> SHADE =
            ENTITIES.register("shade", () -> EntityType.Builder
                    .of(Shade::new, MobCategory.MISC)
                    .sized(0.6f, 1.95f)
                    .clientTrackingRange(10)
                    .build("shade"));
}
