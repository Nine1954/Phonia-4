package com.phobia;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

// Client -> server: the player's eyes are closed (true) or open (false).
// While closed the client re-sends every few ticks, and the server lets the state expire on its own.
public record BlinkPayload(boolean closed) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<BlinkPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Phobia.MODID, "blink"));

    public static final StreamCodec<ByteBuf, BlinkPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, BlinkPayload::closed,
            BlinkPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(BlinkPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                PlayerStats s = sp.getData(Phobia.STATS);
                s.blinkClosedUntil = payload.closed() ? sp.level().getGameTime() + 14L : 0L;
            }
        });
    }
}
