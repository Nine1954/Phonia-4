# Phobia (batch 1) - NeoForge 1.21.1

Contents: Sanity, Stamina, in-game config, /phobia commands, anti-cheat (dark figure grab -> kill or kick).

## Build
Requirements: JDK 21, Gradle 8.8+ (or open the folder in IntelliJ IDEA, it sets up Gradle for you).

    gradle wrapper        # once, to create ./gradlew
    ./gradlew runClient   # test in game
    ./gradlew build       # jar in build/libs

If Gradle can't find the NeoForge version, set `neo_version` in gradle.properties to the
latest 21.1.x from https://projects.neoforged.net/neoforged/neoforge

## In game
- Config: Mods -> Phobia -> Config (stamina loss 10/s, gain 20/s by default). Open it inside a world.
- Commands (op): /phobia stamina loss|gain|max|resume <value>, /phobia sanity <0-100>
- Anti-cheat mode (OFF / KILL / KICK) is in the config. /phobia commands are exempt.
- Anything in the tag data/phobia/tags/entity_type/birds.json scares the player (parrots for now).

## Known limits
- Anti-cheat catches cheat COMMANDS (list is configurable). Creative mode picked at world creation is not detected.
- Food-free sprinting is approximate (see ServerEvents.onPlayerPre); a Mixin can make it exact later.

## Build without a PC (GitHub Actions)
1. Create a GitHub repo and upload everything in this folder (keep the folder structure, including .github/).
2. Open the repo -> Actions -> "build" -> wait for the green check.
3. Open that run -> Artifacts -> download phobia-jar. Unzip it: the .jar inside goes into your mods folder.
Note: the zip you download is NOT the mod. The .jar inside it is.
